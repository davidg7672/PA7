/*
David Sosa Vidal
CPSC 122
Professor Jacob Shea
Programming Assignment 7, Stacks and Inheritance
Main Function File
*/

#include "PA7.h"

int main(void) {
	
	// Executes and does everything
	execution();
	
	return 0;
}